/******************************************************************************
** Shows/Hides the options
**************************/
void frmAbout::init()
{
  teHowToPlay->hide();
  this->adjustSize();
}

void frmAbout::showHideHowToPlay(bool direction)
{    
    if (direction== 1 )
    {
	teHowToPlay->show();
	this->adjustSize();
	pbHowToPlay->setText(tr("&How to Play <<"));
    }
    else if (direction == 0 )
    {
	teHowToPlay->hide();
	this->adjustSize();
	pbHowToPlay->setText(tr("&How to Play >>"));
    }
}
