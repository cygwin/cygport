<!DOCTYPE TS><TS>
<context>
    <name>GuessoForm</name>
    <message>
        <source>Guesso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remeber:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>o means correct digit in correct order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>.  means correct digit but in wrong order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter 4 digits then press enter to start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your Guess</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>9999; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;New Game</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Options &gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>the secret number may contain duplicated digits.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Difficulty:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Easy ( 12 tries )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Normal ( 8 tries )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hard ( 5 tries )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Congratulations, You WON !! =)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is your last try, good luck</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Options &lt;&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You lost , the secret number was %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You still have %1 tries</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>frmAbout</name>
    <message>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;&lt;font size=&quot;+1&quot;&gt;Version&lt;/font&gt;&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A Simple guess-the-number game</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p align=&quot;center&quot;&gt;&lt;b&gt;By Mohamed Assar&lt;/b&gt;  &lt;tt&gt;mohasr@gmail.com&lt;/tt&gt;&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;There is a secret number consists of 4 digits , and you have 8 tries to guess those 4 digits in the correct order to findout the secret number.&lt;/p&gt;

&lt;p&gt;when you enter 4 digits , you&apos;ll see a dot &apos;.&apos; or a small &apos;o&apos; or just nothing,
the dot means there is a correct digit between the 4 digits you&apos;ve entered but it is in the wrong order ,
the small o means there is a correct digit between the 4 digits you&apos;ve entered and it is also in the correct order.&lt;/p&gt;
&lt;font size=&quot;-1&quot;&gt;&lt;p&gt;a little hint: to know the secret number, open the game from the console.&lt;/p&gt;&lt;/font&gt;
&lt;p&gt;Good luck =)&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;&lt;font size=&quot;+1&quot;&gt;0.3&lt;/font&gt;&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;How to Play &lt;&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;How to Play &gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+H</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
