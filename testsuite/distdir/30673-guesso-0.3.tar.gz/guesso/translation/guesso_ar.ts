<!DOCTYPE TS><TS>
<context>
    <name>GuessoForm</name>
    <message>
        <source>Guesso</source>
        <translation>خمّنه</translation>
    </message>
    <message>
        <source>Remeber:</source>
        <translation>تذكر:</translation>
    </message>
    <message>
        <source>o means correct digit in correct order</source>
        <translation>تعني o عدد صحيح في مكان صحيح</translation>
    </message>
    <message>
        <source>.  means correct digit but in wrong order</source>
        <translation>تعني . عدد صحيح في مكان خاطئ</translation>
    </message>
    <message>
        <source>Enter 4 digits then press enter to start</source>
        <translation>للبدء أدخل أربعة أعداد ثم اضغط Enter</translation>
    </message>
    <message>
        <source>Your Guess</source>
        <translation>تخمينك</translation>
    </message>
    <message>
        <source>The Result</source>
        <translation>النتيجة</translation>
    </message>
    <message>
        <source>9999; </source>
        <translation></translation>
    </message>
    <message>
        <source>Options</source>
        <translation>خيارات</translation>
    </message>
    <message>
        <source>the secret number may contain duplicated digits.</source>
        <translation>الرقم السري قد يحتوي على أعداد متكررة.</translation>
    </message>
    <message>
        <source>Difficulty:</source>
        <translation>الصعوبة:</translation>
    </message>
    <message>
        <source>Easy ( 12 tries )</source>
        <translation>سهل ( 12 محاولة )</translation>
    </message>
    <message>
        <source>Normal ( 8 tries )</source>
        <translation>عادي ( 8 محاولات )</translation>
    </message>
    <message>
        <source>Hard ( 5 tries )</source>
        <translation>صعب ( خمس محاولات )</translation>
    </message>
    <message>
        <source>&amp;New Game</source>
        <translation>&amp;لعبة جديدة</translation>
    </message>
    <message>
        <source>Alt+N</source>
        <translation></translation>
    </message>
    <message>
        <source>&amp;Options &gt;&gt;</source>
        <translation>&amp;خيارات &gt;&gt;</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation></translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation>&amp;عن البرنامج</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation></translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>خ&amp;روج</translation>
    </message>
    <message>
        <source>Alt+Q</source>
        <translation></translation>
    </message>
    <message>
        <source>Congratulations, You WON !! =)</source>
        <translation>مبروك , لقد فزت !!  :-)</translation>
    </message>
    <message>
        <source>You lost , the secret number was </source>
        <translation type="obsolete">لقد خسرت , الرقم السري كان </translation>
    </message>
    <message>
        <source>You still have </source>
        <translation type="obsolete">لا يزال لديك </translation>
    </message>
    <message>
        <source> tries</source>
        <translation type="obsolete"> محاولات</translation>
    </message>
    <message>
        <source>This is your last try, good luck</source>
        <translation>هذه آخر محاولة , حظا موفقا</translation>
    </message>
    <message>
        <source>&amp;Options &lt;&lt;</source>
        <translation>&amp;خيارات &lt;&lt;</translation>
    </message>
    <message>
        <source>You lost , the secret number was %1</source>
        <translation>لقد خسرت , الرقم السري كان %1</translation>
    </message>
    <message>
        <source>You still have %1 tries</source>
        <translation>لا يزال لديك %1 محاولات</translation>
    </message>
</context>
<context>
    <name>frmAbout</name>
    <message>
        <source>About</source>
        <translation>عن البرنامج</translation>
    </message>
    <message>
        <source>&lt;b&gt;&lt;font size=&quot;+1&quot;&gt;Version 0.2&lt;/font&gt;&lt;font size=&quot;-1&quot;&gt;.1&lt;/font&gt;&lt;/b&gt;</source>
        <translation type="obsolete">&lt;b&gt;&lt;font size=&quot;+1&quot;&gt;الإصدار &lt;/font&gt;&lt;font size=&quot;+1&quot;&gt;0.2&lt;/font&gt;&lt;font size=&quot;-1&quot;&gt;.1&lt;/font&gt;&lt;/b&gt;</translation>
    </message>
    <message>
        <source>A Simple guess-the-number game</source>
        <translation>لعبة بسيطة من طراز خمن الرقم السري</translation>
    </message>
    <message>
        <source>&lt;p align=&quot;center&quot;&gt;&lt;b&gt;By Mohamed Assar&lt;/b&gt;  &lt;tt&gt;mohasr@gmail.com&lt;/tt&gt;&lt;/p&gt;</source>
        <translation>&lt;p align=&quot;center&quot;&gt;&lt;b&gt;محمد عَصَر&lt;/b&gt;  &lt;tt&gt;mohasr@gmail.com&lt;/tt&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>إ&amp;غلاق</translation>
    </message>
    <message>
        <source>Alt+C</source>
        <translation></translation>
    </message>
    <message>
        <source>How to play</source>
        <translation type="obsolete">كيفية اللعب</translation>
    </message>
    <message>
        <source>&lt;p&gt;There is a secret number consists of 4 digits , and you have 8 tries to guess those 4 digits in the correct order to findout the secret number.&lt;/p&gt;

&lt;p&gt;when you enter 4 digits , you&apos;ll see a dot &apos;.&apos; or a small &apos;o&apos; or just nothing,
the dot means there is a correct digit between the 4 digits you&apos;ve entered but it is in the wrong order ,
the small o means there is a correct digit between the 4 digits you&apos;ve entered and it is also in the correct order.&lt;/p&gt;
&lt;font size=&quot;-1&quot;&gt;&lt;p&gt;a little hint: to know the secret number, open the game from the console.&lt;/p&gt;&lt;/font&gt;
&lt;p&gt;Good luck =)&lt;/p&gt;</source>
        <translation>&lt;p&gt;يوجد رقم سري مكون من أربعة عداد يتوجب عليك تخمينه بالترتيب الصحيح, ولديك عدد من المحاولات لإتمام المهمة.&lt;/P&gt;
&lt;p&gt;بعد كل محاولة سترى نتيجة تخمينك مكونة من: اما نقطة &apos;.&apos; أو دائرة صغيرة &apos;o&apos; أو مجرد فراغ . النقطة تعني أن هنالك عدد من بين الأربعة الأعداد التي قمت بادخالها صحيح ولكنه في المكان الخاطئ , والدائرة الصغيرة تعني أن هناك عدد من بين الأربعة أعداد التي قمت بإدخالها صحيح وأيضا في المكان الصحيح&lt;/p&gt;
&lt;font size=&quot;-1&quot;&gt;&lt;p&gt;تلميح بسيط: إذا أردت معرفة الرقم السري قم بتشغيل البرنامج من سطر الأوامر console&lt;/p&gt;&lt;/font&gt;
&lt;p&gt;بالتوفيق :-)&lt;/p&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;&lt;font size=&quot;+1&quot;&gt;Version&lt;/font&gt;&lt;/b&gt;</source>
        <translation>&lt;b&gt;&lt;font size=&quot;+1&quot;&gt;الإصدار&lt;/font&gt;&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;&lt;font size=&quot;+1&quot;&gt;0.3&lt;/font&gt;&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>How to Play</source>
        <translation type="obsolete">كيفية اللعب</translation>
    </message>
    <message>
        <source>&amp;How to Play &lt;&lt;</source>
        <translation>&amp;كيفية اللعب &lt;&lt;</translation>
    </message>
    <message>
        <source>&amp;How to Play &gt;&gt;</source>
        <translation>&amp;كيفية اللعب &gt;&gt;</translation>
    </message>
    <message>
        <source>Alt+H</source>
        <translation></translation>
    </message>
</context>
</TS>
